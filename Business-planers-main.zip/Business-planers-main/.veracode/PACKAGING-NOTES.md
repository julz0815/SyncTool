# Packaging Notes for Business Planers

## Repository Contents
* Business-planers.sln
    * Visual Studio 17 (2022) solution file
* Business-planers/Business-planers.vcxproj file
    * Visual Studio C++ project file
* Business-planers/main.cpp, Business-planers/Source
    * C++ source files
* Business-planers/Headers
    * C++ header files
* libpqxx-Debug/lib/libpq.dll
    * Debug build of libpqxx
* libpqxx-Release/lib/libpq.dll
    * Release build of libpqxx

## Build Environment
* Windows 10
* Developer Command Prompt for VS 2022
* MSBuild version 17.4.1+9a89d02ff for .NET Framework

## Manual Packaging Contents
* Business-planers.exe
    * Top-level module for analysis
* Business-planers.pdb
    * Debug file required for analysis
* libpq.dll
    * Dependency of Business-planers.exe, not in static environments
        * Required for no missing dependencies preflight warnings
