#pragma once
extern double btc = 0;
extern double eth = 0;
extern double rights = 0;
extern double stocks = 0;