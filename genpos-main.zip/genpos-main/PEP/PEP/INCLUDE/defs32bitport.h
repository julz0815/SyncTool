/*
	Definitions file created for the 32 bit port of PEP.

	R. Chambers		Oct 23, 2002	Initial version
 */
#ifndef DEFS32BITPORT_DEFINED
#define DEFS32BITPORT_DEFINED

#define LOADDS 
#define PIFENTRY


// Following are used for Windows messages and notifications

//
#define WIN_ITEM_ID(w) HIWORD(w)

#endif