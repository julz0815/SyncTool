This folder contains the source code for the SQLite embedded database engine.

Description:  C source code as an amalgamation, version 3.17.0.

Downloaded from https://sqlite.org/download.html on Mar-24-2017.