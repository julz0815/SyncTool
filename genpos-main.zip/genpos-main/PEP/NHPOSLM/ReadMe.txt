*** Layout Manager ***

[TODO: High Priority]
+	Align grids with rulers
+	Fix the initial cursor line at the top
+	Display the name of the highlighted item in the status bar
+	When the first button is created, it is not shown in the treeview.
*	Fix problem with the left-side tree view and the selected UI artifact on the workspace

*	Fix the ruler background (not being painted fully at the top)
*	Maximize the view on New Document
*	Improve usability of button assignment
*	LButtonDown flickers the screen even when there is no action
	This is used for dragging (moving) artifact

