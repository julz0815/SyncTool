// WindowControlSample.cpp : implementation file
//

#include "stdafx.h"
//#include "NewLayout.h"
#include "WindowControlSampleExt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWindowControlSample

CWindowControlSampleExt::CWindowControlSampleExt()
{
}

CWindowControlSampleExt::~CWindowControlSampleExt()
{
}


BEGIN_MESSAGE_MAP(CWindowControlSampleExt, CWnd)
	//{{AFX_MSG_MAP(CWindowControlSampleExt)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CWindowControlSample message handlers
