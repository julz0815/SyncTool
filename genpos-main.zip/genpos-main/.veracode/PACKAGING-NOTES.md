# Packaging Notes for genpos

## Repository Contents
* /nhpos/WS_AllSource.sln
    * Visual Studio 2022 solution file
* /PEP/allPepPCIF.sln
    * Visual Studio 2019 solution file

## Build Environment
* Windows 10
* Developer Command Prompt for VS 2022
* Platform Toolset Visual Studio 2019 (v142)
* MSBuild version 17.10.4+10fbfbf2e for .NET Framework

## Manual Packaging Contents
* /nhpos
    * Exes, dlls, and pdbs require for analysis from build of /nhpos/WS_AllSource.sln
* /PEP
    * Exes, dlls, and pdbs require for analysis from build of /PEP/allPepPCIF.sln
