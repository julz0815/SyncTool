/* $Id: urldecode.h,v 1.2 2008/04/13 20:38:46 laffer1 Exp $ */

#ifndef URLDECODE_H
#define URLDECODE_H

char *spc_decode_url(const char *url, size_t *nbytes) ;

#endif

